from fastapi import FastAPI
from starlette.responses import JSONResponse

app = FastAPI()

@app.get("/")
def get_root():
  return {'message': 'Lab 03'}

import database

@app.get('/books')
def list_books(skip: int=0, limit: int=0):
  cursor = database.db.books.find().skip(skip).limit(limit)
  result = []
  for item in cursor:
    item['_id'] = str(item['_id'])
    result.append(item)
  cursor.close()
  return result


from bson import ObjectId

@app.get('/books/{book_id}')
def get_book_by_id(book_id: str):
  book = database.db.books.find_one({'_id': ObjectId(book_id)})
  if book:
    book['_id'] = str(book['_id'])
    return book
  else:
    return JSONResponse(f'Book not found: {book_id}', 404)
