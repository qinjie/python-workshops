from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi import status
from datetime import datetime

app = FastAPI()

@app.get("/")
def get_root():
  return {'message': 'Lab 02'}

weekdays = {0:'Sun', 1:'Mon', 2:'Tue'}

from typing import Optional
from enum import Enum
class CaseEnum(Enum):
  upper = 'upper'
  lower = 'lower'

@app.get('/weekdays')
def get_weekdays(case: Optional[CaseEnum] = None):
  if case == CaseEnum.upper:
    return { k:v.upper() for k,v in weekdays.items()}
  elif case == CaseEnum.lower:
    return { k:v.lower() for k,v in weekdays.items()}
  else:
    return {'weekdays': weekdays}

@app.get('/weekday/{weekday_id}')
def get_weekday(weekday_id: int):
  try:
    return {'weekday': weekdays[weekday_id]} 
  except:
    content = {'message': f'Invalid weekday ID: {weekday_id}'}
    return JSONResponse(content, status.HTTP_404_NOT_FOUND)

@app.get('/find_weekday/{year}/{month}/{day}')
def find_weekday(year: int, month: int, day: int):
    dt = datetime(year=year, month=month, day=day)
    wd = dt.weekday()
    return {'weekday': weekdays[wd]}