from typing import List, Optional
from fastapi import FastAPI
from pydantic.main import BaseModel
from starlette.responses import JSONResponse

app = FastAPI()

@app.get("/")
def get_root():
  return {'message': 'Lab 05'}


# @app.put('/books/{book_id}')
# def update_book(book_id: str, book: Book):
#   d = book.dict()
#   d['_id'] = book_id
#   return d

# @app.delete('/books/{book_id}')
# def delete_book(book_id: str):
#   return {'_id': book_id}


from database import *
from bson import ObjectId

class Book(BaseModel):
  title: str
  authors: List[str] = None
  tags: List[str] = None
  pages: Optional[int] = None
  publishes: Optional[int] = None


# Replace an item
@app.put('/books/{book_id}')
def update_book(book_id: str, book: Book):
  try:
    result = db.books.replace_one({'_id':ObjectId(book_id)}, book.dict())      
    return {'matched_count': result.matched_count, 'modified_count': result.modified_count}
  except Exception as e:
    print(repr(e))
    return JSONResponse({'error': str(e)}, 500)


@app.delete('/books/{book_id}')
def delete_book(book_id: str):
  result = db.books.delete_one({'_id': ObjectId(book_id)})
  return {'deleted_count': result.deleted_count}

