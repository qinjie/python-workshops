from pymongo import MongoClient

# MongoDB attributes
mongodb_url = 'mongodb+srv://root:qwer1234@cluster0.hlixs.mongodb.net/demo?retryWrites=true&w=majority'

try:
  client = MongoClient(mongodb_url)
  db = client['demo']
  print('Connected to MongoDB')
except Exception as e:
  print(repr(e))
  raise Exception('Error in MongoDB connection.')
