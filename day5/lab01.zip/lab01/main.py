from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def get_root():
  return {'message': 'Hello FastAPI'}

@app.get("/about")
def get_about():
  return {'message': 'This is my first FastAPI project.'}

@app.get('/now')
def get_time():
  from datetime import datetime
  now = datetime.now()
  return {'datetime': now.strftime('%Y-%m-%d %H:%M:%S')}

