from typing import List, Optional
from fastapi import FastAPI
from fastapi.params import Body
from pydantic.main import BaseModel
from starlette.responses import JSONResponse

app = FastAPI()

@app.get('/')
def get_root():
    return {'message': 'Lab 04'}

# @app.post('/books')
# def save_book(book: dict = Body(...)):
#     return book

class Book(BaseModel):
    title: str
    authors: List[str] = None
    tags: List[str] = None
    pages: Optional[int] = None
    publishes: Optional[int] = None

# @app.post('/books')
# def save_book(book: Book):
#     return book

from database import *

@app.post('/books')
def save_book(book: Book):
    try:
        result = db.books.insert_one(book.dict())
        return {'_id': str(result.inserted_id)}
    except Exception as e:
        print(repr(e))
        return JSONResponse({'message': 'Error in saving book'}, 500)

